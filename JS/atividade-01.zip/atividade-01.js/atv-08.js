
const iife (function(){
    console.log('Olá Diego Max!')
})
();

