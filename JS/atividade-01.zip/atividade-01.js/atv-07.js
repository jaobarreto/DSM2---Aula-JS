
const Soma = (a, b, c, d) => {
    return a + b + c + d 
}

console.log(Soma(1, 2, 3, 4))