
function multiplicacaoTres (a, b, c){

    return a * b * c

}

console.log(`O resultado da multiplicação desses 3 números é: ${multiplicacaoTres(10, 10, 10)}`)