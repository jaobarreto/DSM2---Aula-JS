
function divisao (a, b) {

    let divisao = a / b
    
    console.log(`O resultado da divisão deste números é igual a ${divisao}` )
}

divisao(10, 2)