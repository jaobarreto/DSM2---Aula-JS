
const nome = "João Pedro Dias Barreto"

const idade = 19

const cidade = "Cananéia"

function Nome(){
    console.log(nome)
}
Nome()

function Idade(){
    console.log(idade)
}
Idade()

function Cidade(){
    console.log(cidade)
}
Cidade()