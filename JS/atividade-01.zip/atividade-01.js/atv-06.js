
const triplo = (x) => {
    return x * 3
}

console.log(`O triplo do número é ${triplo(10)}`)